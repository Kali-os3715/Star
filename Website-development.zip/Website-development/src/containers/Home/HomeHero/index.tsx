import React, {FC} from 'react';

import * as S from './Styles';

const HomeHero: FC = () => {
  return <S.Container>Hello</S.Container>;
};

export default HomeHero;
