export interface NavigationItem {
  name: string;
  url: string;
}
