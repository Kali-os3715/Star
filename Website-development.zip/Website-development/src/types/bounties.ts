export enum SortBy {
  created = 'Sort By Created Date',
  none = 'Sort By None',
  reward = 'Sort By Reward',
}
