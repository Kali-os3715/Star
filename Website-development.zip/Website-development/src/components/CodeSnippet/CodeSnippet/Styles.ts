import styled from 'styled-components';
import {b1} from 'styles/fonts';

export const Heading = styled.div`
  ${b1.regular}
  margin-bottom: 2px;
`;
