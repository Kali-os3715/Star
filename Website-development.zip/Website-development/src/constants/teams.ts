export const allTeamsFilter = {
  pathname: 'All',
  title: 'All',
};
