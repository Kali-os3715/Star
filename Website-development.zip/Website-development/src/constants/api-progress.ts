export enum ApiProgress {
  Ok = 'Ok',
  Error = 'Error',
  Success = 'Success',
  Init = 'Init',
  Requesting = 'Requesting',
}
