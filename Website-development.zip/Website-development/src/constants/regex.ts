export const REGEX = {
  containsNumber: /[\d]/i,
  excludingNumber: /[^\d.]/g,
  githubWeightedLabel: /PR\s\/[\d|\s|Task]+\/\s/g,
};
