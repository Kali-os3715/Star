export const EMAIL = 'contact@thenewboston.com';
