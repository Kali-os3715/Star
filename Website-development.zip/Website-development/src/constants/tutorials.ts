export const allTutorialsFilter = {
  pathname: 'All',
  title: 'All',
};
